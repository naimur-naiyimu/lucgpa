from setuptools import setup, find_packages

setup(
    name="lucgpa",
    version="1.0",
    packages=find_packages(),
    install_requires=[],
    author="lu boss",
    author_email="lu@boss.com",
    description="A simple example Python package",
    url="https://github.com/naimur-naiyimu/lucgpa.git",
)